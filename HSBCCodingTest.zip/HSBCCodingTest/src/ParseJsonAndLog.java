
/* 
Question:
Write a java program (java >8) that calls and parses the JSON endpoint
(https://samples.openweathermap.org/data/2.5/box/city?bbox=12,32,15,37,10&appid=b6907d289e10d714a6e88b30761fae22) 
and outputs the number of cities with parameter "name" begins with the letter "T" to a log file.
Code should be uploaded to an external public git repository, eg https://github.com/ or https://bitbucket.org 
*/

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;

public class ParseJsonAndLog {

	public static final String url = "https://samples.openweathermap.org/data/2.5/box/city?bbox=12,32,15,37,10&appid=b6907d289e10d714a6e88b30761fae22";
	public static final String cityInfoArrayObjectName = "list";
	public static final String cityNameStartsWith = "T";
	public static final String parameter2Search = "name";
	public static final String logFileName = "cityNameStartWithT.log";

	public static void main(String[] args) {

		try (InputStream inputStream = new URL(url).openStream()) {

			JsonReader jsonReader = Json.createReader(inputStream);
			JsonObject jsonObjectFromReader = jsonReader.readObject();
			JsonArray jsonArray = jsonObjectFromReader.getJsonArray(cityInfoArrayObjectName);

			List<JsonObject> listJsonObject = jsonArray.getValuesAs(JsonObject.class);

			List<JsonObject> listJsonObjectCityNameStartWithT = listJsonObject.stream()
					.filter(jsonObject -> jsonObject.getString(parameter2Search).startsWith(cityNameStartsWith))
					.collect(Collectors.toList());

			List<String> cityNameStartWithT = listJsonObjectCityNameStartWithT.stream()
					.map(jsonObject -> jsonObject.getString(parameter2Search)).collect(Collectors.toList());

			try (PrintWriter printWriter = new PrintWriter(Files.newBufferedWriter(Paths.get(logFileName)))) {
				cityNameStartWithT.forEach(printWriter::println);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
